name : Nikhil Chaudhari		
B-number: B00640143

1) Add a new shell command (print messages in user space)
status: Complete

2) Print messages in kernel space
status: complete


Discription: For the second part, i have used a global variable fl which is 
initially set to 0 and changed when we first print the message in kernal space.

logs:

test case 1:

xv6...
cpu1: starting
CS550 proj0 printing in kernel space
cpu0: starting
sb: size 1000 nblocks 941 ninodes 200 nlog 30 logstart 2 inodestart 32 bmap start 58
init: starting sh
$ proj0 Hello World
CS550 proj0 print in user space: Hello World
$ 

test case 2:

$ proj0 CS 550 Operating Systems Section 4
CS550 proj0 print in user space: CS 550 Operating Systems Section 4
$ 

test case 3:

$ proj0 CS 550 Operating Systems Section 4
CS550 proj0 print in user space: CS 550 Operating Systems Section 4
$ 




